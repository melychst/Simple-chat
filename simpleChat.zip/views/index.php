<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="main-page-heaader">
				<h1>Welcome to simple chat</h1>
				<a href="login">Sign in</a> / <a href="register">Sign up</a>			
			</div>
		</div>
	</div>
</div>