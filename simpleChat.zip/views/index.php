<div class="container">
	<div class="row">
		<div class="col-md-12">
			<h1>Welcome to simple chat</h1>
			<a href="login">Sign in</a> / <a href="register">Sign up</a>
		</div>
	</div>
</div>