<?php

/**
* Config
*/
class Config 
{
	
	function __construct(argument)
	{
		# code...
	}
}
?>