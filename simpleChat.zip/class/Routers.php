<?php

/**
* Routers
*/
class Routers {
	
	public function getUrl() {
		include($_SERVER['DOCUMENT_ROOT']."/views/sign-up.php");
	}
}

?>