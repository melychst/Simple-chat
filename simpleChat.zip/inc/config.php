<?php

define("ROOT", $_SERVER['DOCUMENT_ROOT']);
define("USER", "root");
define("PASSWORD", "");
define("HOST", "localhost");
define("DB", "chat");

?>