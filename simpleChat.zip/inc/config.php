<?php

define("ROOT", $_SERVER['DOCUMENT_ROOT']);
define("USER", "root");
define("PASSWORD", "");
define("HOST", "localhost");
define("DB", "chat");
define("CAPTCHA", "6LexByMUAAAAABaVA4KhuU_HvuMu6fdrD2xfkiTd");
define("CAPTCA_SECRET", '6LexByMUAAAAAISQUMnxRoS8qToaPlLKaS1j6jx7');

?>